[USER]
id_user = id
v_username = username
v_forum_name = forum_name
v_password = password
v_company = company
v_email = email
v_first_name = first_name
v_last_name = last_name
i_status = 
v_ip =
d_registration =
d_last_login =
v_basic_details =
i_random =
v_thumb =

[BOARD]
id_board = id
id_forum = 
v_board_title = board_title
v_description = description
d_created = 
i_post_captcha =
i_access = 
i_thread_count = 
id_last_thread = 
v_last_post_title = 
id_last_posted_by = 
v_last_posted_by = 
d_last_posted =
i_post_count = post_count
id_reorder = id_reorder


[POST]
id_post = id
id_board = id_board
v_post_title = post_title
v_description = description
v_image = image
d_post_time = 
v_username = username
id_user = id_user
v_ip = ip
id_parent = id_parent
id_thread = id_thread
id_forum = 