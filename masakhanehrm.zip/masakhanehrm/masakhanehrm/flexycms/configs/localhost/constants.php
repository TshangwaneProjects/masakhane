<?php
define("DB_HOST",'localhost');
define("DB_USER",'hrm_user'); // MySql User nameg
define("DB_PASS",'hrm_database_123'); // MySql passwordg
define("DB_DB",'hrm_database'); // MySql Database Nameg
define("AFIXI_THEME",''); // Document root of application g
//define("TABLE_PREFIX" ,'flexy__');g
define("TABLE_PREFIX" ,'hrm__');
define("LINKS_PREFIX",'links_');
define("ROLES_ROOT",AFIXI_ROOT.'/configs/'.SITE_USED.'/');
?>