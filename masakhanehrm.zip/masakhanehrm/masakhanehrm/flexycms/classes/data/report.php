<?
class report{
	function report(){
		
	}
}
?>