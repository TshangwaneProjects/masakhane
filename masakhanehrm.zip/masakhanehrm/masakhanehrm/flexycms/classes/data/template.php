<?
class template{
	function template(){
		
	}
}
?>