<?
class module{
	
}
?>