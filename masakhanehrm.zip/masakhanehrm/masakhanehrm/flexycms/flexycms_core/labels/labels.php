<?php 
define("LBL_SITE_URL",'http://AFrame.localhost/');
 
 //sample 
define("LBL_USERNAME", 'Username');
define("LBL_PASS", 'Password');
define("LBL_FIRST_NAME", 'First Name');
define("LBL_LAST_NAME", 'Last Name');
define("LBL_QUESTION", 'Question');
define("LBL_ANSWER", 'Answer');
