<?php
/*
 * Created on Mar 13, 2006
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 
//define("LBL_SITE_URL",'http://baxter.afixiindia.com/');
define("LBL_CONTENT_IMG_URL",LBL_SITE_URL.'waf_res/waf_content/images/');
define("LBL_CONTENT_THUMB_URL",'/waf_res/waf_content/content_thumbnails/');
define("LBL_CONTENT_ORIG_URL",LBL_SITE_URL.'waf_res/waf_content/orig/');
define("LBL_USER_THUMB_URL",LBL_SITE_URL.'waf_res/waf_content/user_avtar/');
define('ULBL_I_SKIP_CAPTCHA', 'Enter the image text:' );
//define("LBL_ADMIN_SITE_URL",'http://baxter.afixiindia.com/flexycms/myadmin/');
//define("LBL_BULK_UPLOAD_URL",'http://baxter.afixiindia.com/waf_res/waf_content/bulkupload/');
//define("LBL_BULK_UPLOAD_THUMB_URL",'http://baxter.afixiindia.com/waf_res/waf_content/bulkupload_thumbnails/');
 
 //sample 
define("LBL_USERNAME", 'Username');
define("LBL_PASS", 'Password');
define("LBL_FIRST_NAME", 'First Name');
define("LBL_LAST_NAME", 'Last Name'); 
?>
