<?php
/*
 * Class   : user_bl 
 * Purpose : All business logic(Data Query) related to user_manager done here
 */
class user_bl extends business{	

};
