<?
class template_bl extends business{

}
?>