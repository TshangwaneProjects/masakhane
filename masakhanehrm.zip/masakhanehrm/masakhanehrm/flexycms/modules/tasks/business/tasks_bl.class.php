<?php
/**
 * Class   : adminstration_bl
 * Purpose : All data query(DQL) of administration manager done here. 
 */
class tasks_bl extends business{
};

